# EduLinux - Context Persistence (Updated December 13, 2025)

## Latest Session: Advanced Screen Sharing Features

### User Request:
1. Teacher can share entire screen (PC/phone/tablet), not just website content
2. Universal document viewer for all file types (PDF, images, videos, Office)
3. Teacher can view and control student screens in real-time

### Completed Implementation:

#### 1. WebSocket Signaling Server
- `server/websocket.ts` - Full WebRTC signaling server
- Integrated in `server/index.ts`
- Handles: start-share, stop-share, offer, answer, ice-candidate, screen requests

#### 2. WebRTC Hook
- `client/src/hooks/useWebRTCScreenShare.ts`
- Uses navigator.mediaDevices.getDisplayMedia for real screen capture
- Supports teacher broadcasting and student screen monitoring
- ICE servers: Google STUN servers

#### 3. New Components
- `client/src/components/apps/universal-document-viewer.tsx` - PDF, images, videos, text
- `client/src/components/apps/real-screen-viewer.tsx` - Live video stream viewer
- `client/src/components/teacher/student-screen-monitor.tsx` - Student screen grid
- `client/src/components/student/screen-request-dialog.tsx` - Consent dialog

#### 4. Updated Pages
- Teacher Dashboard: Added "Mon écran complet" option, new "Surveillance" tab
- Student Desktop: WebRTC integration, RealScreenViewer, ScreenRequestDialog

### Important Notes:
- Remote control of student computers NOT possible via pure web - needs native app
- Students must consent before screen is shared with teacher
- WebSocket path: `/ws/screenshare`

## Previous Features (Still Working)
- 13 workstations with teacher station
- Colorful theme
- Screen sharing with content types
- Teacher activity view
- LibreOffice-style file management
- Text editor with file saving
- Browser with YouTube/Google
- Math tools
- Teacher account management

## Key Files:
- `server/websocket.ts`, `server/index.ts`
- `client/src/hooks/useWebRTCScreenShare.ts`
- `client/src/pages/teacher-dashboard.tsx`, `client/src/pages/student-desktop.tsx`
- All new components in `client/src/components/`
